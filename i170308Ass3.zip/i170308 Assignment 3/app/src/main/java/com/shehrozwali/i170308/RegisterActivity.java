package com.shehrozwali.i170308;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import java.util.HashMap;


public class RegisterActivity extends AppCompatActivity {
EditText email,password,passwordConfirm;

Button btn_Register;
private int idVal = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Intent i= getIntent();
        email=findViewById(R.id.email);
        password=findViewById(R.id.createPassword);
        passwordConfirm=findViewById(R.id.confirmPassword);



        btn_Register=findViewById(R.id.btn_Register);
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt_email=email.getText().toString();
                Random rand = new Random();
                int randNo = rand.nextInt(10);
                String randomNum=Integer.toString(randNo);
                String txt_username="";

                /*Converting Email to Char Array for users*/
                char[]  charEmail= txt_email.toCharArray();
                for (int i=0;charEmail[i]!='@';i++){

                    txt_username+=charEmail[i];
                }


                String txt_password=password.getText().toString();
                String txt_passwordConfirm=passwordConfirm.getText().toString();
                if (TextUtils.isEmpty(txt_email)||TextUtils.isEmpty(txt_password)||TextUtils.isEmpty(txt_passwordConfirm) ){

                    Toast.makeText(RegisterActivity.this,"All Fields are required",Toast.LENGTH_SHORT).show();
                }

                else if (txt_password.length()<5){
                    Toast.makeText(RegisterActivity.this,"Password must be atleast 5 character",Toast.LENGTH_SHORT).show();
                }
                else {

                    register(txt_username,txt_email,txt_password);

                }
            }
        });

    }
    private void register(final String username,String email, String password){

        final RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

        // Enter the correct url for your api service site
        String url = "http://192.168.10.6/chatapp/user_login.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(RegisterActivity.this,"Registered Successfully",Toast.LENGTH_SHORT).show();
                getID(email, requestQueue);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(RegisterActivity.this,"Error: "+error.getMessage().toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {



                Map<String, String> params = new HashMap<String, String>();
                params.put("username", username);
                params.put("email", email);
                params.put("password", password);

                return params;
            }
        };

        requestQueue.add(stringRequest);


    }

    private void getID(final String email, RequestQueue queue) {
        String url = "http://192.168.10.6/chatapp/user_validate.php";

        StringRequest stringRequest = new StringRequest(Request.Method.GET,url,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        idVal = findID(response, email);

                        Intent intent = new Intent(getApplicationContext(), CreateProfileActivity.class);


                        intent.putExtra("id", idVal);
                        startActivity(intent);
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Log.v("wwww",error.toString());
                    }
                });

        queue.add(stringRequest);
    }

    private int findID(String res, String email) {
        int idx = res.indexOf(email);
        idx = res.indexOf("ID:", idx);
        boolean x = false;
        String id = "";


        for(int i = idx + 3; x == false && i < res.length(); ++i){
            if(res.charAt(i) != ' ')
                id += res.charAt(i);
            else
                x = true;
        }

        if (!id.isEmpty()){
            return Integer.parseInt(id);
        }

        return -123;
    }


    public void goSignInButton(View view) {
        startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
    }
}